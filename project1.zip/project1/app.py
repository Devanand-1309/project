from flask import Flask, request, jsonify
import pandas as pd
from pymongo import MongoClient
import os

app = Flask(__name__)

# Configure the MongoDB connection
client = MongoClient('mongodb://localhost:27017/')
db = client['new']
collection = db['new']

UPLOAD_FOLDER = 'uploads'
if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/upload', methods=['POST'])
def upload_file():
    if 'file' not in request.files:
        return 'No file part'
    
    file = request.files['file']
    if file.filename == '':
        return 'No selected file'

    if file:
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
        file.save(file_path)

        data = pd.read_csv(file_path)
        records = data.to_dict(orient='records')

        collection.insert_many(records)

        return 'File uploaded and data inserted successfully.'

if __name__ == '__main__':
    app.run(debug=True)
